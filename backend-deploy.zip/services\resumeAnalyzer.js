const Anthropic = require('@anthropic-ai/sdk');
const pdfParse = require('pdf-parse');
const fs = require('fs').promises;
const path = require('path');

// Initialize Anthropic client
const anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY
});

/**
 * Extract text from PDF resume
 */
async function extractTextFromPDF(filePath) {
    const dataBuffer = await fs.readFile(filePath);
    const data = await pdfParse(dataBuffer);
    return data.text;
}

/**
 * Analyze resume using Claude AI with HVAC-specific criteria
 */
async function analyzeResume(filePath) {
    try {
        // Extract text from resume
        let resumeText;
        const ext = path.extname(filePath).toLowerCase();

        if (ext === '.pdf') {
            resumeText = await extractTextFromPDF(filePath);
        } else {
            // For DOC/DOCX, you'd need additional library like mammoth
            // For now, we'll handle PDF only
            throw new Error('Only PDF files are currently supported');
        }

        // Create the AI prompt specifically for HVAC technician evaluation
        const prompt = `You are an expert HVAC industry recruiter. Analyze the following resume for an HVAC technician position and provide a detailed evaluation.

Resume Content:
${resumeText}

Please analyze this resume and provide your evaluation in the following JSON format:

{
  "overallScore": <number 0-100>,
  "summary": "<brief 2-3 sentence summary>",
  "technicalSkills": {
    "score": <number 0-100>,
    "found": ["<list of HVAC skills found>"],
    "missing": ["<important HVAC skills that are missing>"],
    "feedback": "<specific feedback>"
  },
  "certifications": {
    "score": <number 0-100>,
    "found": ["<certifications found, e.g., EPA 608, NATE, etc.>"],
    "recommended": ["<certifications they should pursue>"],
    "feedback": "<specific feedback>"
  },
  "experience": {
    "score": <number 0-100>,
    "yearsOfExperience": <number>,
    "relevantExperience": ["<list relevant HVAC experience>"],
    "feedback": "<specific feedback>"
  },
  "presentationQuality": {
    "score": <number 0-100>,
    "strengths": ["<formatting, clarity, professionalism strengths>"],
    "improvements": ["<areas to improve>"],
    "feedback": "<specific feedback>"
  },
  "strengths": ["<top 3-5 strengths>"],
  "weaknesses": ["<top 3-5 weaknesses>"],
  "recommendations": ["<3-5 specific recommendations for improvement>"],
  "hiringRecommendation": "<STRONG_YES|YES|MAYBE|NO|STRONG_NO>"
}

Key HVAC skills to look for:
- EPA 608 Universal Certification
- NATE Certification
- HVAC Installation & Maintenance
- Refrigeration Systems
- Air Conditioning Systems
- Heating Systems (Gas, Electric, Oil)
- Ductwork Installation
- Troubleshooting & Diagnostics
- HVAC Controls & Thermostats
- Commercial vs Residential Experience
- Load Calculations
- Blueprint Reading
- Safety Protocols
- Customer Service

Provide thorough, honest, and actionable feedback.`;

        // Call Claude API
        const message = await anthropic.messages.create({
            model: "claude-sonnet-4-20250514",
            max_tokens: 2048,
            messages: [{
                role: "user",
                content: prompt
            }]
        });

        // Parse the response
        const responseText = message.content[0].text;

        // Extract JSON from response (Claude might wrap it in markdown)
        let jsonMatch = responseText.match(/\{[\s\S]*\}/);
        if (!jsonMatch) {
            throw new Error('Failed to parse AI response');
        }

        const analysis = JSON.parse(jsonMatch[0]);

        // Convert overallScore (0-100) to scoreOutOf10
        analysis.scoreOutOf10 = Math.round(analysis.overallScore / 10);

        // Clean up the uploaded file after analysis
        await fs.unlink(filePath).catch(err => console.error('Error deleting file:', err));

        return analysis;

    } catch (error) {
        console.error('Error analyzing resume:', error);
        throw error;
    }
}

module.exports = {
    analyzeResume
};
