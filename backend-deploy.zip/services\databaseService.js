const db = require('../config/database');

// Helper function to convert arrays to JSON for SQLite
const toJSON = (value) => {
    if (Array.isArray(value)) {
        return JSON.stringify(value);
    }
    return value;
};

// Helper function to parse JSON from SQLite
const fromJSON = (value) => {
    if (typeof value === 'string' && (value.startsWith('[') || value.startsWith('{'))) {
        try {
            return JSON.parse(value);
        } catch (e) {
            return value;
        }
    }
    return value;
};

/**
 * User operations
 */
const userService = {
    async create(email, passwordHash, companyName = null) {
        const result = await db.query(
            'INSERT INTO users (email, password_hash, company_name) VALUES (?, ?, ?) RETURNING *',
            [email, passwordHash, companyName]
        );
        return result.rows[0];
    },

    async findByEmail(email) {
        const result = await db.query('SELECT * FROM users WHERE email = ?', [email]);
        return result.rows[0];
    },

    async findById(id) {
        const result = await db.query('SELECT * FROM users WHERE id = ?', [id]);
        return result.rows[0];
    }
};

/**
 * Batch operations
 */
const batchService = {
    async create(userId, name, totalResumes) {
        const result = await db.query(
            'INSERT INTO batches (user_id, name, total_resumes) VALUES (?, ?, ?) RETURNING *',
            [userId, name, totalResumes]
        );
        return result.rows[0];
    },

    async findByUserId(userId) {
        const result = await db.query(
            'SELECT * FROM batches WHERE user_id = ? ORDER BY created_at DESC',
            [userId]
        );
        return result.rows;
    },

    async findById(id) {
        const result = await db.query('SELECT * FROM batches WHERE id = ?', [id]);
        return result.rows[0];
    }
};

/**
 * Candidate operations
 */
const candidateService = {
    async create(batchId, filename, filePath) {
        const result = await db.query(
            'INSERT INTO candidates (batch_id, filename, file_path, status) VALUES (?, ?, ?, ?) RETURNING *',
            [batchId, filename, filePath, 'analyzing']
        );
        return result.rows[0];
    },

    async updateStatus(id, status) {
        const result = await db.query(
            'UPDATE candidates SET status = ? WHERE id = ? RETURNING *',
            [status, id]
        );
        return result.rows[0];
    },

    async findByBatchId(batchId) {
        const result = await db.query(
            `SELECT c.*, a.score_out_of_10, a.summary, a.hiring_recommendation
             FROM candidates c
             LEFT JOIN analyses a ON c.id = a.candidate_id
             WHERE c.batch_id = ?
             ORDER BY a.score_out_of_10 DESC`,
            [batchId]
        );
        return result.rows;
    },

    async findById(id) {
        const result = await db.query('SELECT * FROM candidates WHERE id = ?', [id]);
        return result.rows[0];
    }
};

/**
 * Analysis operations
 */
const analysisService = {
    async create(candidateId, analysisData) {
        const {
            overallScore,
            scoreOutOf10,
            summary,
            technicalSkills,
            certifications,
            experience,
            presentationQuality,
            strengths,
            weaknesses,
            recommendations,
            hiringRecommendation
        } = analysisData;

        const result = await db.query(
            `INSERT INTO analyses (
                candidate_id, overall_score, score_out_of_10, summary,
                technical_skills_score, technical_skills_found, technical_skills_missing, technical_skills_feedback,
                certifications_score, certifications_found, certifications_recommended, certifications_feedback,
                experience_score, years_of_experience, relevant_experience, experience_feedback,
                presentation_score, presentation_strengths, presentation_improvements, presentation_feedback,
                strengths, weaknesses, recommendations, hiring_recommendation
            ) VALUES (
                ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?
            ) RETURNING *`,
            [
                candidateId, overallScore, scoreOutOf10, summary,
                technicalSkills.score, toJSON(technicalSkills.found), toJSON(technicalSkills.missing), technicalSkills.feedback,
                certifications.score, toJSON(certifications.found), toJSON(certifications.recommended), certifications.feedback,
                experience.score, experience.yearsOfExperience, toJSON(experience.relevantExperience), experience.feedback,
                presentationQuality.score, toJSON(presentationQuality.strengths), toJSON(presentationQuality.improvements), presentationQuality.feedback,
                toJSON(strengths), toJSON(weaknesses), toJSON(recommendations), hiringRecommendation
            ]
        );
        return result.rows[0];
    },

    async findByCandidateId(candidateId) {
        const result = await db.query('SELECT * FROM analyses WHERE candidate_id = ?', [candidateId]);
        const analysis = result.rows[0];
        if (analysis) {
            // Parse JSON fields
            analysis.technical_skills_found = fromJSON(analysis.technical_skills_found);
            analysis.technical_skills_missing = fromJSON(analysis.technical_skills_missing);
            analysis.certifications_found = fromJSON(analysis.certifications_found);
            analysis.certifications_recommended = fromJSON(analysis.certifications_recommended);
            analysis.relevant_experience = fromJSON(analysis.relevant_experience);
            analysis.presentation_strengths = fromJSON(analysis.presentation_strengths);
            analysis.presentation_improvements = fromJSON(analysis.presentation_improvements);
            analysis.strengths = fromJSON(analysis.strengths);
            analysis.weaknesses = fromJSON(analysis.weaknesses);
            analysis.recommendations = fromJSON(analysis.recommendations);
        }
        return analysis;
    },

    async getFullAnalysis(candidateId) {
        const result = await db.query(
            `SELECT c.*, a.*
             FROM candidates c
             JOIN analyses a ON c.id = a.candidate_id
             WHERE c.id = ?`,
            [candidateId]
        );
        const analysis = result.rows[0];
        if (analysis) {
            // Parse JSON fields
            analysis.technical_skills_found = fromJSON(analysis.technical_skills_found);
            analysis.technical_skills_missing = fromJSON(analysis.technical_skills_missing);
            analysis.certifications_found = fromJSON(analysis.certifications_found);
            analysis.certifications_recommended = fromJSON(analysis.certifications_recommended);
            analysis.relevant_experience = fromJSON(analysis.relevant_experience);
            analysis.presentation_strengths = fromJSON(analysis.presentation_strengths);
            analysis.presentation_improvements = fromJSON(analysis.presentation_improvements);
            analysis.strengths = fromJSON(analysis.strengths);
            analysis.weaknesses = fromJSON(analysis.weaknesses);
            analysis.recommendations = fromJSON(analysis.recommendations);
        }
        return analysis;
    }
};

/**
 * Initialize database (create tables)
 */
async function initializeDatabase() {
    const fs = require('fs');
    const path = require('path');

    try {
        const schemaPath = path.join(__dirname, '../database/schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf8');
        await db.query(schema);
        console.log('✅ Database schema initialized');
    } catch (error) {
        console.error('❌ Error initializing database:', error);
        throw error;
    }
}

module.exports = {
    userService,
    batchService,
    candidateService,
    analysisService,
    initializeDatabase
};
